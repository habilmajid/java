# Kuendesha C++ School System kwenye Windows hata MySQL ya XAMPP imekataa

## Unachohitaji

- Windows 10 au 11 na internet kupakua vifaa vya compiler.
- Mradi ulioutoa kwenye ZIP (Extract All) mahali utakapoipata kwa urahisi.
- MSYS2 UCRT64: https://www.msys2.org/ . XAMPP si lazima kwa project hii.

## Hatua ya 1: Install compiler

Install MSYS2 kisha kwenye Start Menu chagua **MSYS2 UCRT64** (si MSYS2 MSYS). Andika:

```bash
pacman -Syu
```

Ikiwa inaomba kufunga terminal baada ya update, ifunge na ufungue tena UCRT64. Halafu:

```bash
pacman -S --needed mingw-w64-ucrt-x86_64-gcc mingw-w64-ucrt-x86_64-cmake mingw-w64-ucrt-x86_64-ninja mingw-w64-ucrt-x86_64-boost mingw-w64-ucrt-x86_64-sqlite3 mingw-w64-ucrt-x86_64-openssl
```

Thibitisha:

```bash
g++ --version
cmake --version
```

## Hatua ya 2: Ingia ndani ya folder

Ikiwa ume-extract ZIP kwenye `C:\Users\JinaLako\Downloads\ZanzibarSmartSchoolSystem`, andika kwenye UCRT64 terminal:

```bash
cd /c/Users/JinaLako/Downloads/ZanzibarSmartSchoolSystem
```

Badili `JinaLako` na jina halisi la folder ya kompyuta yako. Ikiwa path ina nafasi, iandike kwenye alama za kunukuu:

```bash
cd "/c/Users/Jina Lako/Downloads/ZanzibarSmartSchoolSystem"
```

Thibitisha faili zipo:

```bash
ls
```

Unapaswa kuona `CMakeLists.txt`, `src`, `public`, n.k.

## Hatua ya 3: Compile C++

```bash
cmake -S . -B build -G Ninja
cmake --build build
```

Output inayotarajiwa ni `build/school_server.exe`.

## Hatua ya 4: Weka akaunti ya Admin na anzisha server

Kwenye terminal HII HIYO UCRT64:

```bash
export ADMIN_EMAIL="admin@example.test"
export ADMIN_PASSWORD="BadilishaNenosiriLako123!"
export DEMO_SEED=1
./build/school_server.exe
```

Email na password unaweza kuzibadilisha, lakini password iwe na angalau herufi 12. `DEMO_SEED=1` inajaza wanafunzi/walimu wa mfano tu, wakati database ni mpya na haina wanafunzi.

Ukiona ujumbe `listening at http://localhost:8080`, fungua browser:

**http://localhost:8080**

Ingia kwa email na nenosiri uliloweka. **Usifunge terminal** wakati unatumia website: hiyo terminal inaendesha server.

## MySQL ya XAMPP inahusikaje?

Haihusiki kwenye toleo hili! Mfumo umechagua **SQLite local** kwa makusudi, ili uweze kuanza kujifunza kabla hujatatua tatizo la MySQL. C++ hii si faili la PHP la kuweka kwenye `htdocs`. Ina server yake ya HTTP kwenye port `8080`.

Unaweza kutumia XAMPP kwa miradi ya PHP yako wakati huohuo. Ikiwa `8080` inatumika, kabla ya kuendesha C++ weka:

```bash
export PORT=8090
./build/school_server.exe
```

Halafu fungua `http://localhost:8090`.

## Ukipata makosa

- `g++: command not found`: hujafungua **UCRT64** au compiler haijawekwa.
- `boost/json.hpp: No such file`: install `mingw-w64-ucrt-x86_64-boost`.
- `sqlite3.h: No such file`: install `mingw-w64-ucrt-x86_64-sqlite3`.
- `First run: set ADMIN_EMAIL and ADMIN_PASSWORD`: weka exports za hatua ya 4.
- `bind: Address already in use` au port imechukuliwa: weka `PORT=8090`.
- `Database mode: sqlite`: hii ni SAHIHI ukiwa local; haihitaji MySQL.
- Ukifuta `data/school.db`, rekodi zote za SQLite zinapotea. Usifanye bila backup.

## Maelezo ya nenosiri

Nenosiri la Admin hupangwa mara ya **kwanza** unapoanzisha database mpya. Ukibadilisha `ADMIN_PASSWORD` baadaye bila kubadilisha database, password ya zamani bado itatumika. Toleo hili bado halina kipengele cha kubadili password. Usiwahi kutuma password yako kwenye chat, picha au GitHub.
