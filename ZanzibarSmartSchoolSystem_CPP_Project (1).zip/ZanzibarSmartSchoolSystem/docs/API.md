# REST API reference (kwa kujifunzia)

Base URL: `http://localhost:8080`. All endpoints are same-origin; server also serves `/`, `/app.js`, `/styles.css`, `/favicon.svg`.

## Authentication

All data endpoints require an HttpOnly cookie received after login. No tokens in localStorage.

| Method | Endpoint | Maelezo |
|---|---|---|
| GET | `/health` | Healthcheck and database mode; publicly readable |
| GET | `/api/session` | Session status and admin email |
| POST | `/api/login` | JSON: `{ "email":"...", "password":"..." }` |
| POST | `/api/logout` | Logout session |

## CRUD resources

| Resource | GET list | POST create fields | DELETE |
|---|---|---|---|
| Wanafunzi | `/api/students` | `admission_no`, `full_name`, `class_name` | `/api/students/:id` |
| Walimu | `/api/teachers` | `full_name`, `subject` | `/api/teachers/:id` |
| Matokeo | `/api/results` | `student_id` (integer), `subject`, `score` (0-100 integer), `term` | `/api/results/:id` |
| Ada | `/api/payments` | `student_id` (integer), `amount` (integer TZS), `note` | `/api/payments/:id` |
| Ratiba | `/api/timetable` | `class_name`, `day_name`, `lesson_time`, `subject`, `teacher_name` | `/api/timetable/:id` |

`GET /api/dashboard` returns `{ students, teachers, results, payments, timetable, average }`. All HTTP POST data sent as `application/json`. Unauthorized requests return HTTP 401. Successful create is HTTP 201. Unknown endpoints are HTTP 404.

## Examples (for local terminal; use own password)

```bash
# Login and store the session cookie locally:
curl -c cookies.txt -X POST http://localhost:8080/api/login \
  -H 'Content-Type: application/json' \
  -d '{"email":"admin@example.test","password":"BadilishaNenosiriLako123!"}'

# List students:
curl -b cookies.txt http://localhost:8080/api/students

# Add a test student:
curl -b cookies.txt -X POST http://localhost:8080/api/students \
  -H 'Content-Type: application/json' \
  -d '{"admission_no":"ZNZ-020","full_name":"Amina Salim","class_name":"Kidato cha 1"}'
```

`cookies.txt` inapaswa kutunzwa kwa siri, na **haipaswi kupakiwa kwenye GitHub**.

## Data handling

SQL statements use bound parameters to avoid simple SQL injection. Deleting a student cascades to their results/payments in the demo database. Records are still sensitive if real; do not use live student data in this training app. Production systems need permissions, audit logs, backups, proper privacy processes, and more security testing.
