# Jinsi ya kuhost bure: Render (C++ server) + Neon (database)

Mwongozo huu umeandaliwa kwa mradi huu uliomo kwenye ZIP, Oktoba 2026. Bure = $0 katika mipaka ya free tier, **si unlimited hosting**. Huduma zinaweza kubadilisha masharti yao.

## Kabla ya kuanza

- Kwa usalama, tumia **data za mfano tu**. Mradi huu ni MVP ya kujifunzia.
- Hakikisha project inafanya kazi kwenye PC kwanza ukipata nafasi (si lazima kwa deployment).
- Unahitaji akaunti GitHub, Neon na Render na internet.
- **Usiweke password halisi au Neon database URL kwenye GitHub**. Unaweka siri hizi ndani ya Render Environment Variables pekee.

## A. Tengeneza PostgreSQL ya bure kwenye Neon

1. Fungua https://neon.com na create account / login.
2. Chagua **New Project**. Ipe jina `zanzibar-school`.
3. Neon itakupa connection details (PostgreSQL connection string).
4. Copy **connection string** inayofanana na huu MFANO (USITUMIE huu mfano ku-connect):

   ```text
   postgresql://USER:PASSWORD@HOST/neondb?sslmode=require
   ```

5. Ihifadhi kwa siri hadi Render settings; usiitumie kwenye source code/commit/chat. Endpoint ya Neon unaweza kutumia connection string ya direct au pooled kama inavyopendekezwa na Neon.
6. Hakikisha string yako ina `sslmode=require` (au mpangilio mkali zaidi wa uthibitishaji wa SSL ulioidhinishwa na mtoa huduma).

**Kwa nini Neon?** Database yake ni ya kudumu nje ya Render instance, hivyo ku-restart kwa Render hakufuti data. Free tier bado ina limits za storage, compute, network.

## B. Peleka source code kwenye GitHub

1. Fungua https://github.com/new na tengeneza repo, mfano `zanzibar-smart-school` (chagua Private kama unaona inafaa; jifunze permissions za Render + GitHub).
2. Extract ZIP kwenye PC.
3. Kwenye folder yenye `CMakeLists.txt`, tumia GitHub Desktop (https://desktop.github.com/) ku-create repository ya folder hili na **Publish repository**. Au tumia Git CLI ikiwa unaifahamu.
4. Repo inapaswa kuwa na mafaili yote: `Dockerfile`, `CMakeLists.txt`, `src/`, `public/`, `docs/`, `render.yaml`.
5. **Usipakie** folder `build/`, `data/`, faili `.env`, au password. `.gitignore` inasaidia kulinda haya.

Ukichagua Git command line kwa repo mpya bila README:

```bash
git init
git add .
git commit -m "Initial C++ school system"
git branch -M main
git remote add origin https://github.com/USERNAME/zanzibar-smart-school.git
git push -u origin main
```

Badili `USERNAME` kuwa jina lako la GitHub; utahitaji kuingia kwa GitHub kwa njia inayokubalika (GitHub haipokei account password ya kawaida kwenye `git push`).

## C. Tengeneza Render Web Service

1. Fungua https://dashboard.render.com
2. Bonyeza **New → Web Service**.
3. Connect GitHub na chagua repository yako.
4. Runtime: chagua **Docker** (au acha Render itambue `Dockerfile`).
5. Instance Type / Plan: **Free**.
6. Kabla ya deploy, weka **Environment Variables** hizi kwenye sehemu ya Environment (kutegemea UI ya Render, unaweza kuweka kisha kubonyeza deploy):

   | Variable | Value |
   |---|---|
   | `DATABASE_URL` | Connection string halisi uliyocopy kutoka Neon |
   | `ADMIN_EMAIL` | Email ya Admin uliyoiamua |
   | `ADMIN_PASSWORD` | Password ya kipekee yenye angalau herufi 12 |
   | `COOKIE_SECURE` | `1` |
   | `DEMO_SEED` | `1` kwa taarifa za mfano za kujifunzia, au `0` kuanza bila rekodi |

7. Bonyeza **Create Web Service / Deploy**. Render itajenga image kutoka Dockerfile na kuanzisha C++ server.
8. Ukiwa umefanikiwa, URL itakuwa mfano `https://zanzibar-smart-school.onrender.com` (URL yako inaweza kuwa tofauti).
9. Fungua `/health` kwanza, kwa mfano `https://YOUR-NAME.onrender.com/health`. Inapaswa kuonyesha:

   ```json
   {"ok":true,"database":"postgres"}
   ```

10. Fungua homepage ya URL hiyo, ingia kwa `ADMIN_EMAIL` na `ADMIN_PASSWORD` ulizoweka.

**Kama kuna kosa:** Render dashboard → **Logs**. `First run: set ADMIN_EMAIL...` ina maana environment variables hazijawekwa vizuri. `Cannot connect to PostgreSQL` ina maana `DATABASE_URL` si sahihi au Neon haipatikani. Angalia kwamba unatumia `postgresql://...` URL kamili yenye SSL settings.

## D. Kitu muhimu kuhusu password

Admin wa kwanza hutengenezwa tu ikiwa jedwali la admin liko tupu. Kubadili `ADMIN_PASSWORD` kwenye Render baada ya admin kuwa tayari kwenye Neon hakubadili password iliyohifadhiwa. Toleo la kujifunzia halina kipengele cha "change password". Kwa mradi wa kweli, jenga kipengele cha reset/rotation na audit kabla ya matumizi halisi.

## E. Bure kuna mipaka gani?

- **Render Free**: server hulala baada ya takriban dakika 15 bila maombi, na huamka mtumiaji anapofungua website (inaweza kuchelewa). Kuna takriban **750 instance hours** kwa workspace kwa mwezi, bandwidth/build limits, na free plan si kwa production.
- **Render disk**: hakuna persistent disk kwenye Free; **usiitumie SQLite kwa rekodi zinazotakiwa kubaki kwenye Render Free**. Lazima tumia `DATABASE_URL` ya Neon. Usihifadhi faili muhimu ndani ya Render instance.
- **Render Free Postgres** yenyewe huisha baada ya siku 30; kwa sababu hiyo, hapa tumetumia **Neon**, si Render Free PostgreSQL.
- **Neon Free**: ina storage na compute limits; mafanikio ya kuendelea $0 yanategemea kubaki ndani ya limits na sera za wakati huo. Neon ilitangaza **1 GB per project** kwenye Free tier (Oktoba 2, 2026).
- Hostname ya `.onrender.com` na cheti cha HTTPS hutolewa na Render; domain yako binafsi inaweza kuwa na gharama ikiwa utaamua kuinunua.

## F. Usalama

Project ni prototype: ina admin moja, hakuna 2FA, hakuna role-based access kwa walimu/wanafunzi, hakujajengwa data export/restore, automated backups, audit logs, password reset, au payment gateway. **Usitumie taarifa halisi za wanafunzi au fedha**. Kabla ya kuiweka kwenye shule halisi, pima usalama, privacy, usimamizi na sera za shule.

## Official links (tarehe ya mwongozo: 22 Oktoba 2026)

- https://render.com/docs/your-first-deploy
- https://render.com/docs/free
- https://render.com/docs/deploys
- https://neon.com/blog/neon-free-plan-1-gb-per-project
- https://neon.com/docs/connect/connect-from-any-app
