'use strict';

const $ = (selector) => document.querySelector(selector);
const formatInt = (n) => new Intl.NumberFormat('sw-TZ').format(Number(n || 0));
const escapeHtml = (input) => String(input ?? '').replace(/[&<>"']/g, (c) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const state = {page:'dashboard', students:[], email:'', loading:false};
let toastTimer;

async function api(url, options={}) {
  const config = {credentials:'same-origin', ...options};
  if (config.body) config.headers = {'Content-Type':'application/json', ...(config.headers || {})};
  const response = await fetch(url, config);
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    if (response.status === 401 && url !== '/api/login') showLogin();
    throw new Error(data.error || `Server error: ${response.status}`);
  }
  return data;
}
function showLogin() {
  $('#login-view').classList.remove('hidden');
  $('#app-view').classList.add('hidden');
  $('#login-password').value = '';
}
function showApp(email) {
  state.email = email;
  $('#admin-email').textContent = email;
  $('#login-view').classList.add('hidden');
  $('#app-view').classList.remove('hidden');
}
function toast(message, error=false) {
  const node = $('#toast');
  node.textContent = message;
  node.classList.toggle('error', error);
  node.classList.remove('hidden');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => node.classList.add('hidden'), 4000);
}
const pages = {
  students:{title:'Wanafunzi',desc:'Sajili na simamia wanafunzi wa shule.', action:'Ongeza mwanafunzi',endpoint:'students',cols:[['admission_no','Namba'],['full_name','Jina la mwanafunzi'],['class_name','Darasa']],fields:[
    {name:'admission_no',label:'Namba ya usajili',placeholder:'ZNZ-004'},
    {name:'full_name',label:'Jina kamili',placeholder:'Mfano: Amina Salim'},
    {name:'class_name',label:'Darasa',placeholder:'Kidato cha 1'}]},
  teachers:{title:'Walimu',desc:'Hifadhi orodha ya walimu na masomo wanayofundisha.',action:'Ongeza mwalimu',endpoint:'teachers',cols:[['full_name','Jina la mwalimu'],['subject','Somo']],fields:[
    {name:'full_name',label:'Jina la mwalimu',placeholder:'Mfano: Bi. Amina'},
    {name:'subject',label:'Somo analofundisha',placeholder:'Mfano: Kiswahili'}]},
  results:{title:'Matokeo ya Mitihani',desc:'Ingiza alama za mitihani kwa kila mwanafunzi.',action:'Hifadhi matokeo',endpoint:'results',cols:[['student_name','Mwanafunzi'],['subject','Somo'],['score','Alama /100'],['term','Muhula']],fields:[
    {name:'student_id',label:'Chagua mwanafunzi',type:'student'},
    {name:'subject',label:'Somo',placeholder:'Mfano: Hisabati'},
    {name:'score',label:'Alama (0–100)',type:'number',min:0,max:100,placeholder:'85'},
    {name:'term',label:'Muhula',placeholder:'Mfano: Muhula wa 1'}]},
  payments:{title:'Kumbukumbu za Ada',desc:'Rekodi kiasi kilichopokelewa kwa madhumuni ya majaribio.',action:'Ongeza rekodi',endpoint:'payments',cols:[['student_name','Mwanafunzi'],['amount','Kiasi (TZS)'],['note','Maelezo'],['created_at','Tarehe']],fields:[
    {name:'student_id',label:'Chagua mwanafunzi',type:'student'},
    {name:'amount',label:'Kiasi cha mfano (TZS)',type:'number',min:0,max:100000000,placeholder:'35000'},
    {name:'note',label:'Maelezo',placeholder:'Mfano: Muhula wa 1'}],warning:'Huu si mfumo wa malipo ya kweli. Haupokei fedha wala kuunganishwa na benki.'},
  timetable:{title:'Ratiba ya Masomo',desc:'Panga masomo ya kila darasa kwa siku na muda.',action:'Ongeza kipindi',endpoint:'timetable',cols:[['class_name','Darasa'],['day_name','Siku'],['lesson_time','Muda'],['subject','Somo'],['teacher_name','Mwalimu']],fields:[
    {name:'class_name',label:'Darasa',placeholder:'Kidato cha 1'},
    {name:'day_name',label:'Siku',type:'select',options:['Jumatatu','Jumanne','Jumatano','Alhamisi','Ijumaa','Jumamosi']},
    {name:'lesson_time',label:'Muda',placeholder:'08:00 - 09:00'},
    {name:'subject',label:'Somo',placeholder:'Hisabati'},
    {name:'teacher_name',label:'Mwalimu',placeholder:'Bi. Amina'}]}
};

function dateLabel() {
  return new Intl.DateTimeFormat('sw-TZ',{weekday:'long',day:'numeric',month:'long',year:'numeric'}).format(new Date());
}
function header(kicker,title,description,right='') {
  return `<div class="page-header"><div><div class="page-kicker">${escapeHtml(kicker)}</div><h1>${escapeHtml(title)}</h1><p>${escapeHtml(description)}</p></div>${right}</div>`;
}
function statCard(icon,label,value) {
  return `<div class="stat-card"><div class="stat-card-top"><div class="stat-badge" aria-hidden="true">${icon}</div></div><div class="stat-value">${escapeHtml(value)}</div><div class="stat-label">${escapeHtml(label)}</div></div>`;
}
async function renderDashboard() {
  const [stats, students] = await Promise.all([api('/api/dashboard'),api('/api/students')]);
  state.students = students;
  const recents = students.slice(0,5).map((s) => `<div class="person-row"><div class="person-main"><div class="person-icon">${escapeHtml(s.full_name[0]?.toUpperCase() || '?')}</div><div><div class="person-name">${escapeHtml(s.full_name)}</div><div class="person-sub">${escapeHtml(s.admission_no)}</div></div></div><span class="class-pill">${escapeHtml(s.class_name)}</span></div>`).join('');
  $('#content').innerHTML = header('MUHTASARI WA SHULE','Karibu kwenye Dashibodi','Muonekano wa jumla wa taarifa za shule yako.',`<span class="date-chip">▦ ${escapeHtml(dateLabel())}</span>`)
    + `<div class="stat-grid">${statCard('♙','Jumla ya wanafunzi',formatInt(stats.students))}${statCard('▣','Walimu waliosajiliwa',formatInt(stats.teachers))}${statCard('▥','Rekodi za matokeo',formatInt(stats.results))}${statCard('◈','Ada zilizorekodiwa (TZS)',formatInt(stats.payments))}</div>`
    + `<div class="dashboard-bottom"><section class="panel"><div class="panel-head"><div><h2>Wanafunzi wa hivi karibuni</h2><p>Rekodi tano za mwisho</p></div><button type="button" class="link-action" data-goto="students">Ona wote →</button></div>${recents || `<div class="empty-state"><div class="empty-icon">♙</div><strong>Hakuna wanafunzi bado</strong><p>Ongeza mwanafunzi wa kwanza kuanza.</p></div>`}</section><section class="panel quick-card"><div class="quick-graphic" aria-hidden="true"><span>✦</span></div><h2>Elimu inayoendeshwa kwa data</h2><p>Ongeza wanafunzi na rekodi za matokeo. Mfumo utahesabu wastani wa alama moja kwa moja.</p><div class="metric-bar"><span>Wastani</span><div class="metric-track"><div class="metric-progress" style="width:${Math.max(0,Math.min(100, Number(stats.average)))}%"></div></div><strong>${Number(stats.average).toFixed(1)}%</strong></div><button type="button" class="btn btn-primary" data-goto="results">Fungua Matokeo →</button></section></div>`;
  bindGoTo();
}
function fieldHtml(fieldConfig) {
  const {name,label,type='text',placeholder='',min,max,options=[]} = fieldConfig;
  let input;
  const common = `id="form-${name}" name="${name}" required`;
  if (type === 'student') {
    input = `<select ${common}>${state.students.length ? `<option value="">Chagua mwanafunzi</option>` + state.students.map(s => `<option value="${s.id}">${escapeHtml(s.full_name)} — ${escapeHtml(s.admission_no)}</option>`).join('') : `<option value="">Sajili mwanafunzi kwanza</option>`}</select>`;
  } else if (type === 'select') {
    input = `<select ${common}><option value="">Chagua siku</option>${options.map(o=>`<option value="${escapeHtml(o)}">${escapeHtml(o)}</option>`).join('')}</select>`;
  } else {
    input = `<input ${common} type="${type}" placeholder="${escapeHtml(placeholder)}" ${type==='number' ? `min="${min}" max="${max}" step="1"` : 'maxlength="120"'}>`;
  }
  return `<label for="form-${name}">${escapeHtml(label)}</label>${input}`;
}
function displayCell(key, value) {
  if (key === 'amount') return `${formatInt(value)} TZS`;
  if (key === 'score') return `${formatInt(value)} / 100`;
  return escapeHtml(value);
}
function filteredRows(rows, search) {
  const term = search.toLocaleLowerCase('sw');
  return rows.filter(row => Object.values(row).some(value => String(value).toLocaleLowerCase('sw').includes(term)));
}
function tableHtml(config, rows) {
  if (!rows.length) return `<div class="empty-state"><div class="empty-icon">▤</div><strong>Hakuna rekodi zinazoonekana</strong><p>Ongeza rekodi mpya au badilisha neno la kutafuta.</p></div>`;
  return `<div class="table-scroller"><table class="data-table"><thead><tr>${config.cols.map(c=>`<th scope="col">${escapeHtml(c[1])}</th>`).join('')}<th scope="col">Hatua</th></tr></thead><tbody>${rows.map(item=>`<tr>${config.cols.map(([key])=>`<td>${displayCell(key,item[key])}</td>`).join('')}<td><button type="button" class="btn btn-danger" data-remove="${item.id}" aria-label="Futa rekodi ${item.id}">Futa</button></td></tr>`).join('')}</tbody></table></div>`;
}
async function renderDataPage(page) {
  const config = pages[page];
  const [rows, students] = await Promise.all([api(`/api/${config.endpoint}`),api('/api/students')]);
  state.students = students;
  $('#content').innerHTML = header('USIMAMIZI WA SHULE',config.title,config.desc)
    + `<div class="workspace-grid"><section class="panel"><div class="panel-head"><div><h2>Orodha ya ${escapeHtml(config.title)}</h2><p>Taarifa zilizohifadhiwa kwenye database</p></div><strong class="table-total">${formatInt(rows.length)} rekodi</strong></div><div class="table-toolbar"><input class="search-input" type="search" id="search-records" placeholder="Tafuta rekodi..." aria-label="Tafuta rekodi"><span class="count-pill" id="row-counter">${formatInt(rows.length)} zinazoonekana</span></div><div id="table-content">${tableHtml(config,rows)}</div></section><section class="panel form-panel"><div class="form-panel-head"><div class="form-circle">＋</div><h2>${escapeHtml(config.action)}</h2></div><form id="record-form" class="record-form">${config.fields.map(fieldHtml).join('')}<button type="submit" class="btn btn-primary" id="save-record" ${config.fields.some(f=>f.type==='student')&&!students.length?'disabled':''}>Hifadhi rekodi →</button></form><p class="form-hint">Sehemu zote zinahitajika kujazwa.</p>${config.warning?`<div class="warning-note">ⓘ ${escapeHtml(config.warning)}</div>`:''}</section></div>`;
  const search = $('#search-records');
  search.addEventListener('input', () => {
    const filtered = filteredRows(rows, search.value);
    $('#table-content').innerHTML = tableHtml(config, filtered);
    $('#row-counter').textContent = `${formatInt(filtered.length)} zinazoonekana`;
    bindDelete(page);
  });
  bindDelete(page);
  $('#record-form').addEventListener('submit', async (event) => {
    event.preventDefault();
    const button = $('#save-record');
    button.disabled = true;
    button.textContent = 'Inahifadhi...';
    try {
      const form = new FormData(event.currentTarget);
      const data = Object.fromEntries(form.entries());
      for (const fieldConfig of config.fields) {
        if (fieldConfig.type === 'number' || fieldConfig.type === 'student') data[fieldConfig.name] = Number(data[fieldConfig.name]);
      }
      await api(`/api/${config.endpoint}`,{method:'POST',body:JSON.stringify(data)});
      toast('Rekodi imehifadhiwa vizuri. ✓');
      await loadPage(page);
    } catch (e) {
      toast(e.message,true);
      button.disabled = false;
      button.textContent = 'Hifadhi rekodi →';
    }
  });
}
function bindDelete(page) {
  document.querySelectorAll('#table-content [data-remove]').forEach(button => {
    button.addEventListener('click',async () => {
      if (!window.confirm('Unataka kufuta rekodi hii? Hatua hii haiwezi kurudishwa.')) return;
      button.disabled = true;
      try {
        await api(`/api/${pages[page].endpoint}/${button.dataset.remove}`,{method:'DELETE'});
        toast('Rekodi imefutwa.');
        await loadPage(page);
      } catch (e) { toast(e.message,true); button.disabled=false; }
    });
  });
}
function bindGoTo() {
  document.querySelectorAll('[data-goto]').forEach(button => button.addEventListener('click',() => loadPage(button.dataset.goto)));
}
async function loadPage(page) {
  if (state.loading) return;
  state.page = page;
  state.loading = true;
  $('#sidebar').classList.remove('open');
  document.querySelectorAll('.nav-item').forEach(item => item.classList.toggle('active',item.dataset.page===page));
  $('#crumb-page').textContent = page==='dashboard' ? 'Dashibodi' : pages[page].title;
  $('#content').innerHTML = '<div class="loading">Inapakia taarifa...</div>';
  try {
    if (page === 'dashboard') await renderDashboard();
    else await renderDataPage(page);
  } catch (err) {
    $('#content').innerHTML = `<div class="panel empty-state"><div class="empty-icon">!</div><strong>Imeshindikana kupakia taarifa.</strong><p>${escapeHtml(err.message)}</p></div>`;
    toast(err.message,true);
  } finally {state.loading=false;}
}

$('#login-form').addEventListener('submit',async (event) => {
  event.preventDefault();
  const button = $('#login-submit');
  $('#login-error').textContent='';
  button.disabled = true;
  button.textContent = 'Inathibitisha...';
  try {
    const result = await api('/api/login',{method:'POST',body:JSON.stringify({email:$('#login-email').value,password:$('#login-password').value})});
    showApp(result.email);
    await loadPage('dashboard');
  } catch (err) {$('#login-error').textContent=err.message;}
  finally {button.disabled=false;button.innerHTML='Ingia <span aria-hidden="true">→</span>';}
});
$('#logout-btn').addEventListener('click',async () => {
  try {await api('/api/logout',{method:'POST'});} catch (e) {toast(e.message,true);}
  showLogin();
});
$('#menu-toggle').addEventListener('click',() => $('#sidebar').classList.toggle('open'));
document.querySelectorAll('.nav-item').forEach(button => button.addEventListener('click',() => loadPage(button.dataset.page)));

async function init() {
  try {
    const [health, session] = await Promise.all([api('/health'),api('/api/session')]);
    $('#db-mode').textContent = `Database: ${health.database === 'postgres' ? 'PostgreSQL' : 'SQLite'}`;
    if (session.authenticated) {showApp(session.email);await loadPage('dashboard');}
    else showLogin();
  } catch (e) {
    showLogin();
    $('#login-error').textContent='Server haijajibu. Hakikisha C++ server imewashwa.';
  }
}
init();
