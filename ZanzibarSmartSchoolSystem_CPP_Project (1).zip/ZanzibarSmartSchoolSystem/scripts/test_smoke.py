#!/usr/bin/env python3
"""Small dependency-free HTTP integration test for the C++ server (SQLite mode).
Run: python3 scripts/test_smoke.py
"""
import http.cookiejar
import json
import os
from pathlib import Path
import socket
import subprocess
import tempfile
import time
import urllib.error
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
BINARY = ROOT / 'build' / ('school_server.exe' if os.name == 'nt' else 'school_server')


def request(opener, base, path, method='GET', data=None, expected=200):
    payload = json.dumps(data).encode() if data is not None else None
    req = urllib.request.Request(base + path, data=payload, method=method,
                                 headers={'Content-Type': 'application/json'} if payload is not None else {})
    try:
        with opener.open(req, timeout=5) as res:
            status = res.status
            result = res.read()
    except urllib.error.HTTPError as err:
        status = err.code
        result = err.read()
    assert status == expected, f'{method} {path}: HTTP {status}, wanted {expected}; {result[:400]!r}'
    return json.loads(result) if result else {}


def main():
    if not BINARY.is_file():
        raise SystemExit('Compile first: cmake -S . -B build && cmake --build build')
    with tempfile.TemporaryDirectory() as temp:
        with socket.socket() as sock:
            sock.bind(('127.0.0.1', 0))
            port = sock.getsockname()[1]
        env = dict(os.environ, DATABASE_URL='', DB_FILE=str(Path(temp) / 'test.db'),
                   ADMIN_EMAIL='admin@school.test', ADMIN_PASSWORD='A-long-demo-password-9876',
                   DEMO_SEED='1', PORT=str(port))
        app = subprocess.Popen([str(BINARY)], cwd=ROOT, env=env,
                               stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))
        base = f'http://127.0.0.1:{port}'
        try:
            for _ in range(100):
                try:
                    if request(opener, base, '/health')['ok']:
                        break
                except Exception:
                    if app.poll() is not None:
                        raise RuntimeError('Server exited early: ' + app.stderr.read().decode())
                    time.sleep(.08)
            else:
                raise RuntimeError('Server did not start')

            with opener.open(base + '/', timeout=5) as res:
                html = res.read().decode('utf-8')
                assert '<html lang="sw">' in html and 'Content-Security-Policy' in res.headers
            with opener.open(base + '/app.js', timeout=5) as res:
                assert 'renderDashboard' in res.read().decode('utf-8')
            assert request(opener, base, '/api/session')['authenticated'] is False
            request(opener, base, '/api/students', expected=401)
            request(opener, base, '/api/login', 'POST', {'email':'admin@school.test','password':'wrongpass'}, expected=401)
            request(opener, base, '/api/login', 'POST', {'email':'admin@school.test','password':'A-long-demo-password-9876'})
            assert request(opener, base, '/api/session')['authenticated'] is True
            old = request(opener, base, '/api/students')
            assert len(old) == 3 and old[0]['full_name']
            new_student = {'admission_no':'ZNZ-900','full_name':'Mwanafunzi wa Majaribio','class_name':'Kidato cha 4'}
            request(opener, base, '/api/students', 'POST', new_student, expected=201)
            request(opener, base, '/api/students', 'POST', new_student, expected=409)
            student = next(s for s in request(opener, base, '/api/students') if s['admission_no']=='ZNZ-900')
            request(opener, base, '/api/teachers', 'POST', {'full_name':'Bi. Rehema','subject':'Kiswahili'}, expected=201)
            teacher = next(t for t in request(opener, base, '/api/teachers') if t['full_name']=='Bi. Rehema')
            request(opener, base, '/api/results', 'POST', {'student_id':student['id'],'subject':'English','score':101,'term':'Muhula 1'}, expected=400)
            request(opener, base, '/api/results', 'POST', {'student_id':student['id'],'subject':'English','score':90,'term':'Muhula 1'}, expected=201)
            request(opener, base, '/api/payments', 'POST', {'student_id':student['id'],'amount':25000,'note':'Ada ya mfano'}, expected=201)
            request(opener, base, '/api/timetable', 'POST', {'class_name':'Kidato cha 4','day_name':'Jumatano','lesson_time':'09:00 - 10:00','subject':'English','teacher_name':'Bi. Rehema'}, expected=201)
            results = request(opener, base, '/api/results')
            payment = next(p for p in request(opener, base, '/api/payments') if p['student_id']==student['id'])
            assert payment['amount'] == 25000
            schedule = next(s for s in request(opener, base, '/api/timetable') if s['subject']=='English')
            stats = request(opener, base, '/api/dashboard')
            assert stats['students'] == 4 and stats['teachers'] == 3 and stats['payments'] >= 60000
            request(opener, base, f"/api/timetable/{schedule['id']}", 'DELETE')
            request(opener, base, f"/api/teachers/{teacher['id']}", 'DELETE')
            request(opener, base, f"/api/students/{student['id']}", 'DELETE')
            assert not any(r['student_id']==student['id'] for r in request(opener, base, '/api/results'))
            assert not any(p['student_id']==student['id'] for p in request(opener, base, '/api/payments'))
            assert len(request(opener, base, '/api/students')) == 3
            request(opener, base, '/api/logout', 'POST')
            assert request(opener, base, '/api/session')['authenticated'] is False
            request(opener, base, '/api/dashboard', expected=401)
            print('PASS: startup, login, authentication, CRUD, data validation, dashboard, FK cascade, logout')
        finally:
            app.terminate()
            try:
                app.wait(timeout=4)
            except subprocess.TimeoutExpired:
                app.kill()


if __name__ == '__main__':
    main()
