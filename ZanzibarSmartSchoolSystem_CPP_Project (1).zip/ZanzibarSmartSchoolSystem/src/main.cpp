#include "database.hpp"
#include <boost/asio.hpp>
#include <boost/beast.hpp>
#include <boost/json.hpp>
#include <openssl/crypto.h>
#include <openssl/evp.h>
#include <openssl/rand.h>
#include <algorithm>
#include <atomic>
#include <chrono>
#include <cctype>
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <mutex>
#include <optional>
#include <sstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <unordered_map>
#include <utility>
#include <vector>

namespace net = boost::asio;
namespace beast = boost::beast;
namespace http = beast::http;
namespace json = boost::json;
using tcp = net::ip::tcp;
using Request = http::request<http::string_body>;
using Response = http::response<http::string_body>;
using Clock = std::chrono::steady_clock;

static std::string env_or(const char* key, const std::string& default_value = "") {
  const char* v = std::getenv(key);
  return (v && *v) ? std::string(v) : default_value;
}
static bool env_true(const char* key) {
  const auto v = env_or(key);
  return v == "1" || v == "true" || v == "yes";
}
static std::string hex(const unsigned char* bytes, size_t size) {
  static const char* alphabet = "0123456789abcdef";
  std::string out;
  out.reserve(size * 2);
  for (size_t i = 0; i < size; ++i) {
    out += alphabet[bytes[i] >> 4];
    out += alphabet[bytes[i] & 15];
  }
  return out;
}
static std::vector<unsigned char> unhex(const std::string& input) {
  if (input.size() % 2) throw std::runtime_error("Invalid credential data");
  std::vector<unsigned char> result;
  result.reserve(input.size() / 2);
  auto nibble = [](char c) -> int {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    throw std::runtime_error("Invalid credential data");
  };
  for (size_t i = 0; i < input.size(); i += 2)
    result.push_back(static_cast<unsigned char>((nibble(input[i]) << 4) | nibble(input[i + 1])));
  return result;
}
static std::string random_hex(size_t length) {
  std::vector<unsigned char> bytes(length);
  if (RAND_bytes(bytes.data(), static_cast<int>(bytes.size())) != 1)
    throw std::runtime_error("Cryptographic random generation failed");
  return hex(bytes.data(), bytes.size());
}
static std::string password_hash(const std::string& password, const std::string& salt_hex) {
  auto salt = unhex(salt_hex);
  unsigned char hash[32];
  if (PKCS5_PBKDF2_HMAC(password.c_str(), static_cast<int>(password.size()),
                       salt.data(), static_cast<int>(salt.size()), 240000,
                       EVP_sha256(), 32, hash) != 1)
    throw std::runtime_error("Password hashing failed");
  return hex(hash, sizeof(hash));
}
static bool valid_password(const std::string& supplied, const Row& stored) {
  auto candidate = password_hash(supplied, stored.at("salt"));
  const auto& original = stored.at("password_hash");
  return candidate.size() == original.size() &&
         CRYPTO_memcmp(candidate.data(), original.data(), candidate.size()) == 0;
}
static std::string field(const json::object& obj, const char* key, size_t max_len = 100) {
  const auto* value = obj.if_contains(key);
  if (!value || !value->is_string())
    throw std::invalid_argument(std::string("Jaza sehemu: ") + key);
  auto str = std::string(value->as_string().c_str());
  if (str.empty() || str.size() > max_len)
    throw std::invalid_argument(std::string("Urefu usio sahihi: ") + key);
  bool has_content = false;
  for (unsigned char c : str) if (!std::isspace(c)) has_content = true;
  if (!has_content) throw std::invalid_argument(std::string("Jaza sehemu: ") + key);
  return str;
}
static long long number_field(const json::object& obj, const char* key, long long min, long long max) {
  auto* v = obj.if_contains(key);
  if (!v || !v->is_int64()) throw std::invalid_argument(std::string("Namba inahitajika: ") + key);
  auto n = v->as_int64();
  if (n < min || n > max) throw std::invalid_argument(std::string("Namba nje ya kiwango: ") + key);
  return n;
}
static json::object parse_object(const Request& req) {
  auto content_type = req[http::field::content_type];
  if (content_type.find("application/json") == beast::string_view::npos)
    throw std::invalid_argument("Tuma JSON (Content-Type: application/json)");
  beast::error_code ec;
  auto value = json::parse(req.body(), ec);
  if (ec || !value.is_object()) throw std::invalid_argument("JSON si sahihi");
  return value.as_object();
}
static json::array rows_to_json(const Rows& rows) {
  json::array result;
  for (const auto& row : rows) {
    json::object object;
    for (const auto& [k, v] : row) {
      if (k == "id" || k == "student_id" || k == "score" || k == "amount") {
        object[k] = static_cast<int64_t>(std::stoll(v));
      } else {
        object[k] = v;
      }
    }
    result.push_back(std::move(object));
  }
  return result;
}
static bool is_ascii_identifier(const std::string& input) {
  if (input.size() > 32) return false;
  for (unsigned char c : input) {
    if (!(std::isalnum(c) || c == '-' || c == '_' || c == '/')) return false;
  }
  return true;
}
static std::optional<std::string> delete_id(const std::string& path, const std::string& prefix) {
  if (path.rfind(prefix, 0) != 0) return std::nullopt;
  std::string id = path.substr(prefix.size());
  if (id.empty() || id.size() > 15 || !std::all_of(id.begin(), id.end(), [](unsigned char c) { return std::isdigit(c); }))
    throw std::invalid_argument("ID si sahihi");
  if (std::stoll(id) < 1) throw std::invalid_argument("ID si sahihi");
  return id;
}
static std::string read_file(const std::string& filename) {
  std::ifstream file(filename, std::ios::binary);
  if (!file) throw std::runtime_error("Static file missing: " + filename);
  return std::string(std::istreambuf_iterator<char>(file), std::istreambuf_iterator<char>());
}

class App {
  Database db_;
  bool secure_cookie_ = env_true("COOKIE_SECURE");
  struct Session { std::string email; Clock::time_point expires; };
  struct LoginAttempt { int failures = 0; Clock::time_point until = Clock::now(); };
  std::unordered_map<std::string, Session> sessions_;
  std::unordered_map<std::string, LoginAttempt> attempts_;
  std::mutex auth_mutex_;

  Response response(http::status status, std::string body, std::string type, unsigned version = 11) {
    Response res{status, version};
    res.set(http::field::server, "ZanzibarSmartSchool/1.0");
    res.set(http::field::content_type, type);
    res.set(http::field::cache_control, "no-store");
    res.set("X-Content-Type-Options", "nosniff");
    res.set("X-Frame-Options", "DENY");
    res.set("Referrer-Policy", "strict-origin-when-cross-origin");
    res.set("Content-Security-Policy", "default-src 'self'; connect-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'");
    if (secure_cookie_) res.set("Strict-Transport-Security", "max-age=31536000");
    res.body() = std::move(body);
    res.prepare_payload();
    return res;
  }
  Response jres(http::status status, const json::value& body, unsigned ver = 11) {
    return response(status, json::serialize(body), "application/json; charset=utf-8", ver);
  }
  Response error(http::status status, const std::string& message, unsigned ver) {
    return jres(status, json::object{{"error", message}}, ver);
  }
  std::string cookie_token(const Request& req) {
    const auto it = req.find(http::field::cookie);
    if (it == req.end()) return "";
    std::string text(it->value());
    std::istringstream in(text);
    std::string kv;
    while (std::getline(in, kv, ';')) {
      auto pos = kv.find_first_not_of(" \t");
      if (pos == std::string::npos) continue;
      kv.erase(0, pos);
      if (kv.rfind("zss_session=", 0) == 0) return kv.substr(12);
    }
    return "";
  }
  std::string email_for(const Request& req) {
    std::string token = cookie_token(req);
    if (token.size() != 64) return "";
    std::lock_guard<std::mutex> lock(auth_mutex_);
    auto it = sessions_.find(token);
    if (it == sessions_.end()) return "";
    if (Clock::now() >= it->second.expires) {
      sessions_.erase(it);
      return "";
    }
    return it->second.email;
  }
  std::string cookie(const std::string& token, bool erase = false) const {
    return "zss_session=" + token + "; Path=/; HttpOnly; SameSite=Strict" +
           (secure_cookie_ ? "; Secure" : "") +
           (erase ? "; Max-Age=0" : "; Max-Age=28800");
  }
  void init_admin() {
    auto rows = db_.query("SELECT COUNT(*) AS total FROM admins", "SELECT COUNT(*) AS total FROM admins");
    if (std::stoll(rows.at(0).at("total")) != 0) return;
    auto email = env_or("ADMIN_EMAIL");
    auto password = env_or("ADMIN_PASSWORD");
    if (email.empty() || email.size() > 120 || email.find('@') == std::string::npos || password.size() < 12) {
      throw std::runtime_error("First run: set ADMIN_EMAIL and ADMIN_PASSWORD (12+ characters). See README.md");
    }
    std::string salt = random_hex(16);
    std::string hash = password_hash(password, salt);
    db_.query("INSERT INTO admins(email,salt,password_hash) VALUES (?,?,?)",
              "INSERT INTO admins(email,salt,password_hash) VALUES ($1,$2,$3)", {email, salt, hash});
    std::cout << "Admin created: " << email << " (password is not printed)\n";
  }
  void seed_demo() {
    if (!env_true("DEMO_SEED")) return;
    auto row = db_.query("SELECT COUNT(*) AS total FROM students", "SELECT COUNT(*) AS total FROM students");
    if (std::stoll(row.at(0).at("total")) > 0) return;
    db_.query("INSERT INTO students(admission_no,full_name,class_name) VALUES (?,?,?)",
              "INSERT INTO students(admission_no,full_name,class_name) VALUES ($1,$2,$3)", {"ZNZ-001", "Asha Omar", "Kidato cha 1"});
    db_.query("INSERT INTO students(admission_no,full_name,class_name) VALUES (?,?,?)",
              "INSERT INTO students(admission_no,full_name,class_name) VALUES ($1,$2,$3)", {"ZNZ-002", "Salim Juma", "Kidato cha 2"});
    db_.query("INSERT INTO students(admission_no,full_name,class_name) VALUES (?,?,?)",
              "INSERT INTO students(admission_no,full_name,class_name) VALUES ($1,$2,$3)", {"ZNZ-003", "Mariam Ali", "Kidato cha 3"});
    db_.query("INSERT INTO teachers(full_name,subject) VALUES (?,?)",
              "INSERT INTO teachers(full_name,subject) VALUES ($1,$2)", {"Bi. Fatma Said", "Hisabati"});
    db_.query("INSERT INTO teachers(full_name,subject) VALUES (?,?)",
              "INSERT INTO teachers(full_name,subject) VALUES ($1,$2)", {"Bw. Hamad Ali", "Sayansi"});
    auto students = db_.query("SELECT id FROM students WHERE admission_no=?", "SELECT id FROM students WHERE admission_no=$1", {"ZNZ-001"});
    auto id = students.at(0).at("id");
    db_.query("INSERT INTO results(student_id,subject,score,term) VALUES (?,?,?,?)",
              "INSERT INTO results(student_id,subject,score,term) VALUES ($1,$2,$3,$4)", {id, "Hisabati", "87", "Muhula wa 1"});
    db_.query("INSERT INTO payments(student_id,amount,note) VALUES (?,?,?)",
              "INSERT INTO payments(student_id,amount,note) VALUES ($1,$2,$3)", {id, "35000", "Malipo ya mfano"});
    db_.query("INSERT INTO timetable(class_name,day_name,lesson_time,subject,teacher_name) VALUES (?,?,?,?,?)",
              "INSERT INTO timetable(class_name,day_name,lesson_time,subject,teacher_name) VALUES ($1,$2,$3,$4,$5)",
              {"Kidato cha 1", "Jumatatu", "08:00 - 09:00", "Hisabati", "Bi. Fatma Said"});
    std::cout << "Demo-only sample records inserted.\n";
  }
  static std::string single(Database& db, const std::string& sql, const std::string& pg) {
    return db.query(sql, pg).at(0).at("value");
  }
  Response api(const Request& req, const std::string& path, const std::string& peer) {
    auto method = req.method();
    if (path == "/api/session" && method == http::verb::get) {
      auto email = email_for(req);
      return jres(http::status::ok, json::object{{"authenticated", !email.empty()}, {"email", email}}, req.version());
    }
    if (path == "/api/login" && method == http::verb::post) {
      auto data = parse_object(req);
      auto email = field(data, "email", 120);
      auto password = field(data, "password", 256);
      {
        std::lock_guard<std::mutex> lock(auth_mutex_);
        auto& attempt = attempts_[peer];
        if (attempt.failures >= 6 && Clock::now() < attempt.until)
          return error(http::status::too_many_requests, "Majaribio mengi. Jaribu baada ya dakika 10.", req.version());
        if (attempt.failures >= 6 && Clock::now() >= attempt.until) attempt.failures = 0;
      }
      auto rows = db_.query("SELECT salt,password_hash FROM admins WHERE email=?",
                            "SELECT salt,password_hash FROM admins WHERE email=$1", {email});
      bool good = !rows.empty() && valid_password(password, rows.at(0));
      if (!good) {
        std::lock_guard<std::mutex> lock(auth_mutex_);
        auto& a = attempts_[peer];
        a.failures++;
        a.until = Clock::now() + std::chrono::minutes(10);
        return error(http::status::unauthorized, "Barua pepe au nenosiri si sahihi.", req.version());
      }
      auto token = random_hex(32);
      {
        std::lock_guard<std::mutex> lock(auth_mutex_);
        attempts_.erase(peer);
        sessions_[token] = {email, Clock::now() + std::chrono::hours(8)};
      }
      auto res = jres(http::status::ok, json::object{{"ok", true}, {"email", email}}, req.version());
      res.set(http::field::set_cookie, cookie(token));
      return res;
    }
    if (path == "/api/logout" && method == http::verb::post) {
      // Logout is safe even if the previous session has expired.
      auto token = cookie_token(req);
      { std::lock_guard<std::mutex> lock(auth_mutex_); sessions_.erase(token); }
      auto res = jres(http::status::ok, json::object{{"ok", true}}, req.version());
      res.set(http::field::set_cookie, cookie("", true));
      return res;
    }
    if (email_for(req).empty()) return error(http::status::unauthorized, "Ingia kwanza kama Admin.", req.version());

    if (path == "/api/dashboard" && method == http::verb::get) {
      json::object data;
      data["students"] = std::stoll(single(db_, "SELECT COUNT(*) AS value FROM students", "SELECT COUNT(*) AS value FROM students"));
      data["teachers"] = std::stoll(single(db_, "SELECT COUNT(*) AS value FROM teachers", "SELECT COUNT(*) AS value FROM teachers"));
      data["results"] = std::stoll(single(db_, "SELECT COUNT(*) AS value FROM results", "SELECT COUNT(*) AS value FROM results"));
      data["payments"] = std::stoll(single(db_, "SELECT COALESCE(SUM(amount),0) AS value FROM payments", "SELECT COALESCE(SUM(amount),0) AS value FROM payments"));
      data["timetable"] = std::stoll(single(db_, "SELECT COUNT(*) AS value FROM timetable", "SELECT COUNT(*) AS value FROM timetable"));
      data["average"] = std::stod(single(db_, "SELECT COALESCE(AVG(score),0) AS value FROM results", "SELECT COALESCE(AVG(score),0) AS value FROM results"));
      return jres(http::status::ok, data, req.version());
    }
    if (method == http::verb::get) {
      if (path == "/api/students") return jres(http::status::ok, rows_to_json(db_.query(
        "SELECT id,admission_no,full_name,class_name FROM students ORDER BY id DESC",
        "SELECT id,admission_no,full_name,class_name FROM students ORDER BY id DESC")), req.version());
      if (path == "/api/teachers") return jres(http::status::ok, rows_to_json(db_.query(
        "SELECT id,full_name,subject FROM teachers ORDER BY id DESC",
        "SELECT id,full_name,subject FROM teachers ORDER BY id DESC")), req.version());
      if (path == "/api/results") return jres(http::status::ok, rows_to_json(db_.query(
        "SELECT r.id,r.student_id,s.full_name AS student_name,r.subject,r.score,r.term FROM results r JOIN students s ON s.id=r.student_id ORDER BY r.id DESC",
        "SELECT r.id,r.student_id,s.full_name AS student_name,r.subject,r.score,r.term FROM results r JOIN students s ON s.id=r.student_id ORDER BY r.id DESC")), req.version());
      if (path == "/api/payments") return jres(http::status::ok, rows_to_json(db_.query(
        "SELECT p.id,p.student_id,s.full_name AS student_name,p.amount,p.note,p.created_at FROM payments p JOIN students s ON s.id=p.student_id ORDER BY p.id DESC",
        "SELECT p.id,p.student_id,s.full_name AS student_name,p.amount,p.note,p.created_at FROM payments p JOIN students s ON s.id=p.student_id ORDER BY p.id DESC")), req.version());
      if (path == "/api/timetable") return jres(http::status::ok, rows_to_json(db_.query(
        "SELECT id,class_name,day_name,lesson_time,subject,teacher_name FROM timetable ORDER BY id DESC",
        "SELECT id,class_name,day_name,lesson_time,subject,teacher_name FROM timetable ORDER BY id DESC")), req.version());
    }
    if (method == http::verb::post) {
      auto v = parse_object(req);
      if (path == "/api/students") {
        auto admission = field(v, "admission_no", 32);
        if (!is_ascii_identifier(admission)) throw std::invalid_argument("Namba ya usajili tumia herufi, tarakimu, - au / tu.");
        db_.query("INSERT INTO students(admission_no,full_name,class_name) VALUES (?,?,?)",
                  "INSERT INTO students(admission_no,full_name,class_name) VALUES ($1,$2,$3)",
                  {admission, field(v,"full_name",100), field(v,"class_name",60)});
      } else if (path == "/api/teachers") {
        db_.query("INSERT INTO teachers(full_name,subject) VALUES (?,?)",
                  "INSERT INTO teachers(full_name,subject) VALUES ($1,$2)",
                  {field(v,"full_name",100), field(v,"subject",80)});
      } else if (path == "/api/results") {
        auto student = std::to_string(number_field(v,"student_id",1,100000000));
        auto score = std::to_string(number_field(v,"score",0,100));
        db_.query("INSERT INTO results(student_id,subject,score,term) VALUES (?,?,?,?)",
                  "INSERT INTO results(student_id,subject,score,term) VALUES ($1,$2,$3,$4)",
                  {student, field(v,"subject",80), score, field(v,"term",60)});
      } else if (path == "/api/payments") {
        auto student = std::to_string(number_field(v,"student_id",1,100000000));
        auto amount = std::to_string(number_field(v,"amount",0,100000000));
        db_.query("INSERT INTO payments(student_id,amount,note) VALUES (?,?,?)",
                  "INSERT INTO payments(student_id,amount,note) VALUES ($1,$2,$3)",
                  {student, amount, field(v,"note",120)});
      } else if (path == "/api/timetable") {
        db_.query("INSERT INTO timetable(class_name,day_name,lesson_time,subject,teacher_name) VALUES (?,?,?,?,?)",
                  "INSERT INTO timetable(class_name,day_name,lesson_time,subject,teacher_name) VALUES ($1,$2,$3,$4,$5)",
                  {field(v,"class_name",60), field(v,"day_name",30), field(v,"lesson_time",40),
                   field(v,"subject",80), field(v,"teacher_name",100)});
      } else {
        return error(http::status::not_found, "Endpoint haipo.", req.version());
      }
      return jres(http::status::created, json::object{{"ok", true}}, req.version());
    }
    if (method == http::verb::delete_) {
      const std::vector<std::pair<std::string, std::string>> names = {
        {"/api/students/", "students"}, {"/api/teachers/", "teachers"},
        {"/api/results/", "results"}, {"/api/payments/", "payments"},
        {"/api/timetable/", "timetable"}
      };
      for (const auto& [prefix, table] : names) {
        auto id = delete_id(path, prefix);
        if (id) {
          // Table identifiers are from this hardcoded allowlist, not from user input.
          db_.query("DELETE FROM " + table + " WHERE id=?", "DELETE FROM " + table + " WHERE id=$1", {*id});
          return jres(http::status::ok, json::object{{"ok", true}}, req.version());
        }
      }
    }
    return error(http::status::not_found, "Njia haipo.", req.version());
  }

public:
  App() {
    db_.setup();
    init_admin();
    seed_demo();
    std::cout << "Database mode: " << db_.mode() << "\n";
  }
  Response handle(const Request& req, const std::string& peer) {
    try {
      std::string path(req.target());
      const size_t q = path.find('?');
      if (q != std::string::npos) path.resize(q);
      if (path == "/health" && req.method() == http::verb::get)
        return jres(http::status::ok, json::object{{"ok",true}, {"database",db_.mode()}}, req.version());
      if (path.rfind("/api/", 0) == 0) return api(req, path, peer);
      if (req.method() != http::verb::get && req.method() != http::verb::head)
        return error(http::status::method_not_allowed, "Method hairuhusiwi.", req.version());
      std::string filepath;
      std::string content_type;
      if (path == "/" || path == "/index.html") { filepath = "public/index.html"; content_type = "text/html; charset=utf-8"; }
      else if (path == "/styles.css") { filepath = "public/styles.css"; content_type = "text/css; charset=utf-8"; }
      else if (path == "/app.js") { filepath = "public/app.js"; content_type = "text/javascript; charset=utf-8"; }
      else if (path == "/favicon.svg") { filepath = "public/favicon.svg"; content_type = "image/svg+xml"; }
      else return error(http::status::not_found, "Ukurasa haupo.", req.version());
      auto body = read_file(filepath);
      if (req.method() == http::verb::head) body = "";
      return response(http::status::ok, std::move(body), content_type, req.version());
    } catch (const std::invalid_argument& e) {
      return error(http::status::bad_request, e.what(), req.version());
    } catch (const std::exception& e) {
      std::string detail = e.what();
      if (detail.find("UNIQUE constraint") != std::string::npos ||
          detail.find("unique constraint") != std::string::npos ||
          detail.find("duplicate key") != std::string::npos)
        return error(http::status::conflict, "Rekodi hii tayari ipo (namba ya usajili au matokeo yanajirudia).", req.version());
      if (detail.find("FOREIGN KEY constraint") != std::string::npos ||
          detail.find("foreign key constraint") != std::string::npos)
        return error(http::status::bad_request, "Chagua mwanafunzi aliyesajiliwa.", req.version());
      std::cerr << "Request failed: " << e.what() << "\n";
      return error(http::status::internal_server_error, "Hitilafu ya server. Angalia terminal/logs.", req.version());
    }
  }
};

int main() {
  try {
    App app;
    int port = 8080;
    auto p = env_or("PORT");
    if (!p.empty()) port = std::stoi(p);
    if (port < 1 || port > 65535) throw std::runtime_error("PORT must be 1-65535");
    net::io_context context{1};
    tcp::acceptor acceptor{context};
    acceptor.open(tcp::v4());
    acceptor.set_option(net::socket_base::reuse_address(true));
    acceptor.bind(tcp::endpoint(tcp::v4(), static_cast<unsigned short>(port)));
    acceptor.listen();
    std::cout << "Zanzibar Smart School System listening at http://localhost:" << port << "\n";
    std::atomic<int> active{0};
    constexpr int max_active = 64;
    while (true) {
      tcp::socket socket{context};
      acceptor.accept(socket);
      if (active.fetch_add(1) >= max_active) {
        active.fetch_sub(1);
        beast::error_code ignored;
        socket.close(ignored);
        continue;
      }
      std::thread([s = std::move(socket), &app, &active]() mutable {
        struct CounterGuard {
          std::atomic<int>& value;
          ~CounterGuard() { value.fetch_sub(1); }
        } guard{active};
        try {
          const std::string peer = s.remote_endpoint().address().to_string();
          beast::flat_buffer buffer;
          http::request_parser<http::string_body> parser;
          parser.body_limit(65536);
          beast::error_code ec;
          http::read(s, buffer, parser, ec);
          if (!ec) {
            const auto req = parser.release();
            auto res = app.handle(req, peer);
            res.keep_alive(false);
            http::write(s, res, ec);
          }
          s.shutdown(tcp::socket::shutdown_both, ec);
        } catch (const std::exception& e) { std::cerr << "Connection error: " << e.what() << "\n"; }
      }).detach();
    }
  } catch (const std::exception& e) {
    std::cerr << "Startup failed: " << e.what() << "\n";
    return 1;
  }
}
