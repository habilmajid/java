// Boost.JSON compiled implementation (keeps the project free of a JSON .so dependency).
#include <boost/json/src.hpp>
