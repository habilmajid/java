#include "database.hpp"
#include <cstdlib>
#include <filesystem>
#include <stdexcept>
#include <string>

static std::string env_or(const char* name, const std::string& fallback) {
  const char* v = std::getenv(name);
  return (v && *v) ? v : fallback;
}

Database::Database() {
  const char* pg_url = std::getenv("DATABASE_URL");
  if (pg_url && *pg_url) {
#ifdef HAVE_POSTGRESQL
    pg_ = PQconnectdb(pg_url);
    if (PQstatus(pg_) != CONNECTION_OK) {
      std::string error = PQerrorMessage(pg_);
      PQfinish(pg_);
      pg_ = nullptr;
      throw std::runtime_error("Cannot connect to PostgreSQL: " + error);
    }
    postgres_ = true;
#else
    throw std::runtime_error("DATABASE_URL supplied, but this binary was built without PostgreSQL. Install libpq development files and rebuild.");
#endif
  } else {
    std::string filepath = env_or("DB_FILE", "data/school.db");
    auto parent = std::filesystem::path(filepath).parent_path();
    if (!parent.empty()) std::filesystem::create_directories(parent);
    if (sqlite3_open(filepath.c_str(), &sqlite_) != SQLITE_OK) {
      std::string err = sqlite_ ? sqlite3_errmsg(sqlite_) : "unknown";
      if (sqlite_) { sqlite3_close(sqlite_); sqlite_ = nullptr; }
      throw std::runtime_error("Cannot open SQLite file: " + err);
    }
    sqlite3_busy_timeout(sqlite_, 3000);
    char* err = nullptr;
    int rc = sqlite3_exec(sqlite_, "PRAGMA foreign_keys=ON;", nullptr, nullptr, &err);
    if (rc != SQLITE_OK) {
      std::string message = err ? err : "unknown";
      sqlite3_free(err);
      throw std::runtime_error("SQLite settings: " + message);
    }
  }
}

Database::~Database() {
#ifdef HAVE_POSTGRESQL
  if (pg_) PQfinish(pg_);
#endif
  if (sqlite_) sqlite3_close(sqlite_);
}

Rows Database::query(const std::string& sqlite_sql, const std::string& postgres_sql,
                     const std::vector<std::string>& params) {
  std::lock_guard<std::mutex> lock(mutex_);
  Rows rows;
  if (postgres_) {
#ifdef HAVE_POSTGRESQL
    std::vector<const char*> values;
    values.reserve(params.size());
    for (const auto& p : params) values.push_back(p.c_str());
    PGresult* result = PQexecParams(pg_, postgres_sql.c_str(),
                                   static_cast<int>(params.size()), nullptr,
                                   values.data(), nullptr, nullptr, 0);
    if (!result) throw std::runtime_error("PostgreSQL query failed");
    auto status = PQresultStatus(result);
    if (status != PGRES_TUPLES_OK && status != PGRES_COMMAND_OK) {
      std::string err = PQresultErrorMessage(result);
      PQclear(result);
      throw std::runtime_error("Database query failed: " + err);
    }
    if (status == PGRES_TUPLES_OK) {
      for (int r = 0; r < PQntuples(result); ++r) {
        Row row;
        for (int c = 0; c < PQnfields(result); ++c) {
          row[PQfname(result, c)] = PQgetisnull(result, r, c) ? "" : PQgetvalue(result, r, c);
        }
        rows.push_back(std::move(row));
      }
    }
    PQclear(result);
#endif
  } else {
    sqlite3_stmt* stmt = nullptr;
    int rc = sqlite3_prepare_v2(sqlite_, sqlite_sql.c_str(), -1, &stmt, nullptr);
    if (rc != SQLITE_OK) throw std::runtime_error("Database prepare failed: " + std::string(sqlite3_errmsg(sqlite_)));
    try {
      for (size_t i = 0; i < params.size(); ++i) {
        rc = sqlite3_bind_text(stmt, static_cast<int>(i + 1), params[i].c_str(), -1, SQLITE_TRANSIENT);
        if (rc != SQLITE_OK) throw std::runtime_error("SQLite bind failed");
      }
      while ((rc = sqlite3_step(stmt)) == SQLITE_ROW) {
        Row row;
        for (int c = 0; c < sqlite3_column_count(stmt); ++c) {
          const char* key = sqlite3_column_name(stmt, c);
          const unsigned char* value = sqlite3_column_text(stmt, c);
          row[key] = value ? reinterpret_cast<const char*>(value) : "";
        }
        rows.push_back(std::move(row));
      }
      if (rc != SQLITE_DONE) throw std::runtime_error("Database query failed: " + std::string(sqlite3_errmsg(sqlite_)));
    } catch (...) {
      sqlite3_finalize(stmt);
      throw;
    }
    sqlite3_finalize(stmt);
  }
  return rows;
}

void Database::setup() {
  struct Schema { const char* sqlite; const char* pg; };
  const std::vector<Schema> schema = {
    {"CREATE TABLE IF NOT EXISTS admins (id INTEGER PRIMARY KEY AUTOINCREMENT, email TEXT NOT NULL UNIQUE, salt TEXT NOT NULL, password_hash TEXT NOT NULL)",
     "CREATE TABLE IF NOT EXISTS admins (id BIGSERIAL PRIMARY KEY, email TEXT NOT NULL UNIQUE, salt TEXT NOT NULL, password_hash TEXT NOT NULL)"},
    {"CREATE TABLE IF NOT EXISTS students (id INTEGER PRIMARY KEY AUTOINCREMENT, admission_no TEXT NOT NULL UNIQUE, full_name TEXT NOT NULL, class_name TEXT NOT NULL)",
     "CREATE TABLE IF NOT EXISTS students (id BIGSERIAL PRIMARY KEY, admission_no TEXT NOT NULL UNIQUE, full_name TEXT NOT NULL, class_name TEXT NOT NULL)"},
    {"CREATE TABLE IF NOT EXISTS teachers (id INTEGER PRIMARY KEY AUTOINCREMENT, full_name TEXT NOT NULL, subject TEXT NOT NULL)",
     "CREATE TABLE IF NOT EXISTS teachers (id BIGSERIAL PRIMARY KEY, full_name TEXT NOT NULL, subject TEXT NOT NULL)"},
    {"CREATE TABLE IF NOT EXISTS results (id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE, subject TEXT NOT NULL, score INTEGER NOT NULL CHECK(score >= 0 AND score <= 100), term TEXT NOT NULL, UNIQUE(student_id, subject, term))",
     "CREATE TABLE IF NOT EXISTS results (id BIGSERIAL PRIMARY KEY, student_id BIGINT NOT NULL REFERENCES students(id) ON DELETE CASCADE, subject TEXT NOT NULL, score INTEGER NOT NULL CHECK(score >= 0 AND score <= 100), term TEXT NOT NULL, UNIQUE(student_id, subject, term))"},
    {"CREATE TABLE IF NOT EXISTS payments (id INTEGER PRIMARY KEY AUTOINCREMENT, student_id INTEGER NOT NULL REFERENCES students(id) ON DELETE CASCADE, amount INTEGER NOT NULL CHECK(amount >= 0 AND amount <= 100000000), note TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT (datetime('now')))",
     "CREATE TABLE IF NOT EXISTS payments (id BIGSERIAL PRIMARY KEY, student_id BIGINT NOT NULL REFERENCES students(id) ON DELETE CASCADE, amount BIGINT NOT NULL CHECK(amount >= 0 AND amount <= 100000000), note TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT (CURRENT_TIMESTAMP::text))"},
    {"CREATE TABLE IF NOT EXISTS timetable (id INTEGER PRIMARY KEY AUTOINCREMENT, class_name TEXT NOT NULL, day_name TEXT NOT NULL, lesson_time TEXT NOT NULL, subject TEXT NOT NULL, teacher_name TEXT NOT NULL)",
     "CREATE TABLE IF NOT EXISTS timetable (id BIGSERIAL PRIMARY KEY, class_name TEXT NOT NULL, day_name TEXT NOT NULL, lesson_time TEXT NOT NULL, subject TEXT NOT NULL, teacher_name TEXT NOT NULL)"}
  };
  for (const auto& s : schema) query(s.sqlite, s.pg);
}
