#pragma once
#include <map>
#include <mutex>
#include <string>
#include <vector>
#include <sqlite3.h>
#ifdef HAVE_POSTGRESQL
#include <libpq-fe.h>
#endif

using Row = std::map<std::string, std::string>;
using Rows = std::vector<Row>;

class Database {
public:
  Database();
  ~Database();
  Database(const Database&) = delete;
  Database& operator=(const Database&) = delete;
  Rows query(const std::string& sqlite_sql, const std::string& postgres_sql,
             const std::vector<std::string>& params = {});
  void setup();
  std::string mode() const { return postgres_ ? "postgres" : "sqlite"; }
  bool is_postgres() const { return postgres_; }
private:
  bool postgres_ = false;
  sqlite3* sqlite_ = nullptr;
#ifdef HAVE_POSTGRESQL
  PGconn* pg_ = nullptr;
#endif
  std::mutex mutex_;
};
